package com.example.loginhaslo;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    TextView tekst;
    TextView tekst2;
    TextView tekst3;
    TextView tekst4;
    EditText login;
    EditText imie;
    EditText nazwisko;
    EditText haslo;
    Button edytuj;
    Button przeslij;
    boolean odblokowane = false;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
        Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
        v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
        return insets;
    });
        login=findViewById(R.id.login);
        login.getText();

        haslo=findViewById(R.id.haslo);
        haslo.getText();

        imie=findViewById(R.id.imie);
        imie.getText();

        nazwisko=findViewById(R.id.nazwisko);
        nazwisko.getText();

        tekst=findViewById(R.id.tekst);

        tekst2=findViewById(R.id.tekst2);

        tekst3=findViewById(R.id.tekst3);

        tekst4=findViewById(R.id.tekst4);

        edytuj=findViewById(R.id.edytuj);
        przeslij=findViewById(R.id.przeslij);

        edytuj.setOnClickListener(e->{
            odblokowane = !odblokowane;
            login.setEnabled(odblokowane);
            haslo.setEnabled(odblokowane);
            imie.setEnabled(odblokowane);
            nazwisko.setEnabled(odblokowane);
    });

        przeslij.setOnClickListener(e -> {
            tekst.setText(haslo.getText());
            tekst2.setText(login.getText());
            tekst3.setText(imie.getText());
            tekst4.setText(nazwisko.getText());
        });
    }
}